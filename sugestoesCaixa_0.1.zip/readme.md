# comandos do git

cd - mudar de diretorio

cd .. - voltar um diretorio

git add <nome do arquiivo> ou git add . - adicionar um arquivo(ou varios na parte estagio)

> o "git add ." vai adicionar todos os arquivos que estão no diretorio, cuidado para não subir coisa indevida 

git status - (estagio) checa quais arquivos estão prontos para o commit

git commit -m "<mensagem>" - commit, salva as alterações e da um titulo(recomendo as mensagens curtas e claras)

git branch - lista as branchs

git checkout -b <nome da branch> - cria a branch com um nome e já troca automaticamente

git push -u origina <nome da branch> - "empurrar os arquivos para o github"

git pull- atualiza o repositorio local com as alterações do repositorio online 